import { ReplaceDashPipe } from './replace-dash.pipe';

describe('ReplaceDashPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceDashPipe();
    expect(pipe).toBeTruthy();
  });
});
